from paquete1.modulo1 import Cliente
from paquete1.modulo2 import *




nombre= str(input("Ingrese nombre del cliente: "))
correo= str(input("Ingrese correo del cliente: "))
dni= str(input("Ingrese dni del cliente: "))
telefono= str(input("Ingrese telefono del cliente: "))
   

cliente1=Cliente(nombre, correo , dni, telefono)


print("Datos compra")
local=str(input("Ingrese la tienda: "))
producto=str(input("Ingrese producto: "))

cliente1.Comprar(local,producto)



print("Datos descuento")
descuento=str(input("Ingrese descuento: "))
cliente1.descuento(descuento)


print(cliente1)







    


    




