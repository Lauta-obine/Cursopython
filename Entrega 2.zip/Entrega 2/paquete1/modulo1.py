class Cliente:  

    def __init__(self, nombre, correo, dni, telefono):

        self.__nombre=nombre
        self.__correo= correo
        self.__dni= dni
        self.__telefono=telefono

       

    def get_nombre(self, nombre):

        return nombre
    def get_correo(self, correo):

        return correo
    def get_dni(self, dni):

        return dni
    def get_telefono(self, telefono):

        return telefono
    
    def set_nombre(self, nombre):
        self.__nombre=nombre

    def set_correo(self, correo):
        self.__correo=correo    
    
    def set_dni(self, dni):
        self.__dni=dni
    
    def set_correo(self, telefono):
        self.__telefono=telefono       

    

    def Comprar(self, local, producto):

        self.local=local
        self.producto=producto

       

    def descuento(self, descuento):  

        self.descuento=descuento
        
    def __str__(self):

        return "\n EL cliente  " +self.__nombre +" compró en " +self.local + "  un/a " +self.producto +" con un descuento del " +self.descuento
