from setuptools import setup, find_packages # type: ignore

setup(
    name="TuModeloDeClientes+Cestoni",
    version="1.0.0",
    author="Lautaro Cestoni",
    author_email="cestoni96@gmail.com",
    description="Paquete 2da entrega",

  
    packages=find_packages(),
  
   
)